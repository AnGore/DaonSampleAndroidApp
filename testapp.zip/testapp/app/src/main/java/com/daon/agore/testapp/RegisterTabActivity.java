package com.daon.agore.testapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.view.WindowManager;

import com.daon.fido.client.sdk.core.Error;
import com.daon.fido.client.sdk.core.IChooseAuthenticatorCallback;
import com.daon.fido.client.sdk.core.IServerDataAuthenticateCallback;
import com.daon.fido.client.sdk.core.IUafCancellableClientOperation;
import com.daon.fido.client.sdk.core.IUafRegistrationExCallback;
import com.daon.fido.client.sdk.model.Authenticator;
import com.daon.fido.client.sdk.ui.PagedUIAuthenticators;
//import com.daon.fido.sdk.sample.exception.CommunicationsException;
//import com.daon.fido.sdk.sample.exception.ServerError;
//import com.daon.fido.sdk.sample.model.CreateAuthenticator;
//import com.daon.fido.sdk.sample.model.CreateAuthenticatorResponse;
import com.daon.agore.testapp.model.CreateAuthenticator;
import com.daon.agore.testapp.model.CreateAuthenticatorResponse;
import com.daon.agore.testapp.exception.CommunicationsException;
import com.daon.agore.testapp.exception.ServerError;
import com.daon.sdk.authenticator.CaptureFragmentViewPager;
import com.google.gson.Gson;

/**
 * Displays authenticators for registration in tabs. Each factor (face, passcode, pattern etc.)
 * has a separate tab. Authenticators which have not been registered are displayed in their
 * respective tabs. Factors which have been registered display an "already registered" message.
 * Unsupported factors display a "not supported" message.
 */
public class RegisterTabActivity extends BaseTabActivity implements IUafRegistrationExCallback {
    public static final String EXTRA_REG_REQUEST = "RegRequest";
    public static final String EXTRA_ERROR = "Error";
    public static final String EXTRA_REG_RESPONSE = "RegResponse";
    public static final String EXTRA_REG_REQUEST_ID = "RegRequestId";

    protected String registrationRequestId;
    private IUafCancellableClientOperation regOperation;
    private String regRequest;
    protected TabLayout tabLayout;
    protected CaptureFragmentViewPager viewPager;
    protected RegisterFragmentPagerAdapter adapter;
    private SendAdosDataTask mSendAdosDataTask;
    private int tabPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Do the minimum processing possible until registration is underway
        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            if(!processExtras(extras)) {
                finish();
                return;
            }
        }

        register(regRequest);
    }

    protected boolean processExtras(Bundle extras) {
        regRequest = extras.getString(EXTRA_REG_REQUEST, null);
        if(regRequest==null) {
            return false;
        }
        registrationRequestId = extras.getString(EXTRA_REG_REQUEST_ID, null);
        if(registrationRequestId ==null) {
            return false;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        cancel();
    }

    @Override
    public void chooseAuthenticator(Authenticator[][] authenticatorSets, IChooseAuthenticatorCallback authenticatorSetChosen) {
        if(!isScreenCaptureEnabled()) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        }

        // The SDK has processed the policy so we know that the message from the server is valid
        // and there are some authenticators to display, so go ahead and begin setting up the UI...
        setContentView(R.layout.activity_register_tab);

        tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        viewPager = (CaptureFragmentViewPager) findViewById(R.id.pager);

        for (com.daon.sdk.authenticator.Authenticator.Factor factor : RegisterFragmentPagerAdapter.factors) {
            tabLayout.addTab(tabLayout.newTab().setText(factor + ""));
        }

        // Use a bespoke adapter derived from the default SDK adapter. This adapter returns
        // the additional fragments (authenticator registered and not available) that are
        // required for the registration UI.
        adapter = new RegisterFragmentPagerAdapter(getSupportFragmentManager());

        viewPager.setAdapter(adapter);
        viewPager.setSwipingEnabled(false);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        // Notify the SDK that it can continue processing
        authenticatorSetChosen.onChooseAuthenticatorComplete((Authenticator[])null);
    }

    @Override
    public void onPagedUIAuthenticatorsReady(PagedUIAuthenticators authenticators) {
        if(!authenticators.isUpdate()) {
            // The SDK has created the authenticator UI fragments so they can be set on the adapter.
            adapter.setAuthenticators(authenticators);

            // Set the positions of the authenticators to match the tab headings.
            int position = 0;
            for (com.daon.sdk.authenticator.Authenticator.Factor factor : RegisterFragmentPagerAdapter.factors) {
                adapter.setPosition(factor, position);
                position++;
            }

            // Activate the adapter - this updates the ViewPager from displaying a spinner
            // to displaying the fragments
            adapter.activate();

            tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    tabPosition = tab.getPosition();
                    viewPager.setCurrentItem(tabPosition);
                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {
                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {
                }
            });
        } else {
            adapter.updateAuthenticator(authenticators, tabPosition);
        }
    }

    @Override
    public void onUafRegistrationComplete(String registrationResponse) {
        // Return the registration response
        setCurrentFidoOperation(null);
        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_REG_RESPONSE, registrationResponse);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    @Override
    public void onUafRegistrationFailed(Error error) {
        setCurrentFidoOperation(null);
        if(error.getCode() != Error.USER_CANCELLED.getCode()) {
            // Return the error
            Intent resultIntent = new Intent();
            resultIntent.putExtra(EXTRA_ERROR, new Gson().toJson(error));
            setResult(RESULT_OK, resultIntent);
            finish();
        }
    }

    protected void register(String regRequest) {
        regOperation = (IUafCancellableClientOperation)CoreApplication.getFidoSdk().register(regRequest, this);
        setCurrentFidoOperation(regOperation);
    }

    protected void cancel() {
        // Cancel only while the tab display is active
        if(adapter != null && adapter.isActivated()) {
            super.onBackPressed();
            regOperation.cancelAuthenticationUI();
        }
    }

    @Override
    public void onServerData(String serverData, IServerDataAuthenticateCallback serverDataAuthenticated) {
        mSendAdosDataTask = new SendAdosDataTask(registrationRequestId, serverData, serverDataAuthenticated);
        mSendAdosDataTask.execute();
    }

    /**
     * Represents an asynchronous task used to create a FIDO authenticator after a successful registration by a UAF client.
     */
    private class SendAdosDataTask extends AsyncTask<Void, Void, ServerOperationResult<CreateAuthenticatorResponse>> {
        private final CreateAuthenticator createAuthenticator;
        private IServerDataAuthenticateCallback adosDataAuthenticated;

        SendAdosDataTask(String registrationChallengeId, String fidoRegistrationResponse, IServerDataAuthenticateCallback adosDataAuthenticated) {
            createAuthenticator = new CreateAuthenticator();
            createAuthenticator.setRegistrationChallengeId(registrationChallengeId);
            createAuthenticator.setFidoReqistrationResponse(fidoRegistrationResponse);
            this.adosDataAuthenticated = adosDataAuthenticated;
        }

        @Override
        protected ServerOperationResult<CreateAuthenticatorResponse> doInBackground(Void... params) {
            ServerOperationResult<CreateAuthenticatorResponse> result;
            try {
                CreateAuthenticatorResponse response = CoreApplication.getRelyingPartyComms().
                        createAuthenticator(createAuthenticator);
                result = new ServerOperationResult<>(response);
            } catch (ServerError e) {
                result = new ServerOperationResult<>(e.getError());
            } catch (CommunicationsException e) {
                result = new ServerOperationResult<>(e.getError());
            }

            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<CreateAuthenticatorResponse> result) {
            mSendAdosDataTask = null;

            // SERVER RESPONDED OK
            if (result.isSuccessful()) {
                adosDataAuthenticated.onServerAuthenticateComplete(result.getResponse().getFidoRegistrationConfirmation(),
                        result.getResponse().getFidoResponseCode().shortValue());
            } else {
                // SERVER ERROR
                getCurrentFidoOperation().cancelAuthenticationUI();
                onUafRegistrationFailed(new Error(Error.UNEXPECTED_ERROR.getCode(),
                        result.getError().getMessage()));
            }
        }

        @Override
        protected void onCancelled() {
            mSendAdosDataTask = null;
            showProgress(false);
        }
    }
}
