package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class PolicyInfo {
    private String id;
    private String type;
    private String policy;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPolicy() {
        return policy;
    }

    public void setPolicy(String policy) {
        this.policy = policy;
    }
}