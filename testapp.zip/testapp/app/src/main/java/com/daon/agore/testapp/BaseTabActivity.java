package com.daon.agore.testapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.daon.fido.client.sdk.core.IUafCancellableClientOperation;
import com.daon.fido.client.sdk.ui.BaseUIActivity;
import com.daon.sdk.authenticator.util.EventHandler;

public abstract class BaseTabActivity extends AppCompatActivity {
    private boolean visible;
    private volatile Intent pendingLogoutIntent;
    private volatile IUafCancellableClientOperation currentFidoOperation;

    private void logMe(String msg) {
        Log.d("SampleRpApp", "***" + this.getClass().getName() + "***: " + msg);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LocalBroadcastManager.getInstance(this).registerReceiver(mLogoutBroadcastReceiver,
                new IntentFilter(CoreApplication.LOGOUT_BROADCAST_ACTION));
        logMe("BaseTabActivity.onCreate: restart timer and register broadcast receiver");
        CoreApplication.getLogoutCountdown().cancel();
        CoreApplication.getLogoutCountdown().start();
    }

    @Override
    public void onUserInteraction() {
        logMe("BaseTabActivity.onUserInteraction: restart timer");
        CoreApplication.getLogoutCountdown().cancel();
        CoreApplication.getLogoutCountdown().start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        logMe("BaseTabActivity.onResume: visible");
        visible = true;
        if(pendingLogoutIntent != null) {
            performLogout(pendingLogoutIntent);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        logMe("BaseTabActivity.onPause: not visible");
        visible = false;
    }

    @Override
    protected void onDestroy() {
        logMe("BaseTabActivity.onDestroy: unregister broadcast receiver");
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mLogoutBroadcastReceiver);
        super.onDestroy();
    }

    private BroadcastReceiver mLogoutBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            logMe("Receive logout intent broadcast");
            if(currentFidoOperation != null) {
                logMe("Cancel current FIDO operation");
                currentFidoOperation.cancelAuthenticationUI();
                EventHandler.getInstance(getBaseContext()).send(BaseUIActivity.EVENT_CANCEL_SDK_UI, null);
            }
            if(visible) {
                logMe("Visible activity, perform logout");
                performLogout(intent);
            } else {
                logMe("Invisible activity, store pending logout intent");
                pendingLogoutIntent = intent;
            }
        }
    };

    protected void performLogout(Intent logoutIntent) {
        logMe("LoggedInActivity.performLogout");
        showProgress(false);

        pendingLogoutIntent = null;
        Bundle extras = logoutIntent.getExtras();
        boolean success = extras.getBoolean(CoreApplication.EXTRA_LOGOUT_SUCCESS);
        boolean timeout = extras.getBoolean(CoreApplication.EXTRA_LOGOUT_TIMEOUT);
        int errorCode = extras.getInt(CoreApplication.EXTRA_LOGOUT_ERROR_CODE);
        String errorMessage = extras.getString(CoreApplication.EXTRA_LOGOUT_ERROR_MESSAGE);

        logMe("LoggedInActivity.performLogout: success = " + success + ", timeout: " + timeout);

        CoreApplication.getLogoutCountdown().cancel();

        if(success) {
            returnToIntro(timeout);
        } else {
            logMe("LoggedInActivity.performLogout: errorCode: " + errorCode + ", errorMessage: " + errorMessage);
            String error = getResources().getString(R.string.logout_failed) + "\n" + errorMessage;
            Toast.makeText(this, error, Toast.LENGTH_LONG).show();
        }
    }

    protected void returnToIntro(boolean timeout) {
        logMe("LoggedInActivity.returnToIntro with timeout: " + timeout);

        CoreApplication.setSessionId(null);
        Intent newIntent = new Intent(this, MainActivity.class);
        newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(newIntent);
        finish();
        if(timeout) {
            Toast.makeText(this, R.string.logout_due_to_inactivity, Toast.LENGTH_LONG).show();
        }
    }

    public void showProgress(final boolean show) {};

    public IUafCancellableClientOperation getCurrentFidoOperation() {
        return currentFidoOperation;
    }

    public void setCurrentFidoOperation(IUafCancellableClientOperation currentFidoOperation) {
        this.currentFidoOperation = currentFidoOperation;
    }

    protected boolean isScreenCaptureEnabled() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        return sharedPref.getBoolean(SettingsActivity.PREF_SCREEN_CAPTURE, false);
    }

}
