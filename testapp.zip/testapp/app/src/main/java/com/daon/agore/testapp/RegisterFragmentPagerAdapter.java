package com.daon.agore.testapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

import com.daon.fido.client.sdk.ui.CaptureFragmentPagerAdapter;
import com.daon.fido.client.sdk.ui.PagedUIAuthenticators;
import com.daon.sdk.authenticator.Authenticator;
import com.daon.sdk.authenticator.capture.CaptureFragment;
import com.daon.sdk.authenticator.capture.NotSupportedFragment;

/**
 * Displays authenticators under factor headings (finger, face etc.) in a particular order.
 * Factors which are already registered or are not supported on this device have their own specific fragments.
 */
public class RegisterFragmentPagerAdapter extends CaptureFragmentPagerAdapter {
    // Page-order for authenticators
    public static Authenticator.Factor[] factors = new Authenticator.Factor[] {
            Authenticator.Factor.PASSCODE,
            Authenticator.Factor.PATTERN,
            Authenticator.Factor.FINGERPRINT,
            Authenticator.Factor.FACE,
            Authenticator.Factor.VOICE,
            Authenticator.Factor.EYE};

    public RegisterFragmentPagerAdapter(FragmentManager fm, PagedUIAuthenticators authenticators) {
        super(fm, authenticators);
    }

    public RegisterFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    /**
     * Return the number of pages which equals the number of factors.
     * If the parent adapter is locked or not yet activated, get count from the parent class.
     */
    @Override
    public int getCount() {
        int count = super.getCount();

        // Locked
        if(isLocked() || !isActivated()) {
            return count;
        }

        return factors.length;
    }

    /**
     * If the parent returns a fragment then display it. If the parent does not return a fragment
     * it means that there isn't an authenticator associated with the position. In this case
     * return either a "Not supported" or an "Already registered" fragment as appropriate.
     */
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = super.getItem(position);

        if(fragment != null) {
            return fragment;
        }

        if(!CoreApplication.isFactorSupported(factors[position])) {
            return getNotSupportedFragment();
        } else {
            return new RegisteredFragment();
        }
    }

    private CaptureFragment getNotSupportedFragment() {
        Bundle bundle = new Bundle();
        bundle.putBoolean(CaptureFragment.EXTRA_MANAGED, true);

        NotSupportedFragment fragment = new NotSupportedFragment();
        fragment.setArguments(bundle);

        return fragment;
    }
}
