package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class ValidateTransactionAuthResponse {
    private String fidoAuthenticationResponse;
    private Long fidoResponseCode;
    private String fidoResponseMsg;

    public String getFidoAuthenticationResponse() {
        return fidoAuthenticationResponse;
    }
    public void setFidoAuthenticationResponse(String fidoAuthenticationResponse) {
        this.fidoAuthenticationResponse = fidoAuthenticationResponse;
    }
    public Long getFidoResponseCode() {
        return fidoResponseCode;
    }
    public void setFidoResponseCode(Long fidoResponseCode) {
        this.fidoResponseCode = fidoResponseCode;
    }
    public String getFidoResponseMsg() {
        return fidoResponseMsg;
    }
    public void setFidoResponseMsg(String fidoResponseMsg) {
        this.fidoResponseMsg = fidoResponseMsg;
    }
}
