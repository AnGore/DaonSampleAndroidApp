package com.daon.agore.testapp.ados;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class CertificateAccessor implements ICertificateAccessor {
    private static final String KEY_ADOS_ROOT_CERT = "AdosRootCert";

    @Override
    public String getCertificateBase64String(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getString(KEY_ADOS_ROOT_CERT, null);
    }

    @Override
    public void storeCertificate(String base64Certificate, Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(KEY_ADOS_ROOT_CERT, base64Certificate);
        editor.commit();
    }
}
