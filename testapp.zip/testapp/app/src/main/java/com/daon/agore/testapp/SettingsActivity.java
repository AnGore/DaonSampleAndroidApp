package com.daon.agore.testapp;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.daon.agore.testapp.ados.*;
import com.daon.agore.testapp.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Activity which displays application settings
 *
 */
public class SettingsActivity extends Activity {
    public static final String PREF_SERVER_URL = "pref_server_url";
    public static final String PREF_SERVER_PORT = "pref_server_port";
    public static final String PREF_SERVER_SECURE = "pref_server_secure";
    public static final String PREF_LIST_AVAILABLE_AUTHENTICATORS = "pref_list_available_authenticators";
    public static final String PREF_NATIVE_LOGON_ALWAYS = "pref_native_logon_always";
    public static final String PREF_TEXT_TX = "pref_text_tx";
    public static final String PREF_TABBED_REG_UI = "pref_tabbed_reg_ui";
    public static final String PREF_TABBED_AUTH_UI = "pref_tabbed_auth_ui";
    public static final String PREF_TABBED_AUTH_UI_MULTI = "pref_tabbed_auth_ui_multi";
    public static final String PREF_ALT_ADOS_ROOT_CERT_PROVIDED = "pref_alt_ados_root_cert_provided";
    public static final String PREF_ADOS_DEC_SAN = "pref_ados_dec_san";
    public static final String ARG_ADOS_ROOT_CERT = "arg_ados_root_cert";
    public static final String PREF_ADOS_ENABLED = "pref_ados_enabled";
    public static final String PREF_SCREEN_CAPTURE = "pref_screen_capture";

    /**
     * Display the {@link SettingsFragment}
     * @param savedInstanceState saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get intent, action and MIME type
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        String base64EncodedAdosRootCert = null;
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            try {
                if ("text/plain".equals(type)) {
                    base64EncodedAdosRootCert = handleSendText(intent); // Handle text being sent
                } else {
                    base64EncodedAdosRootCert = handleSendCertFile(intent);
                }
            } catch(IllegalArgumentException e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        SettingsActivity.this.finish();
                    }
                }, 3000);
                return;
            }
        }

        // Send ADoS root cert to activity if necessary
        SettingsFragment settingsFragment = new SettingsFragment();
        if(base64EncodedAdosRootCert != null) {
            Bundle args = new Bundle();
            args.putString(ARG_ADOS_ROOT_CERT, base64EncodedAdosRootCert);
            settingsFragment.setArguments(args);
        }

        // Display the fragment as the main content.
        getFragmentManager().beginTransaction().replace(android.R.id.content, settingsFragment).commit();
    }

    private String handleSendCertFile(Intent intent) {
        Uri uri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
        byte[] cert = readFileContents(uri, this);
        ICertificateParser certificateParser = new CertificateParser();
        return certificateParser.parse(cert);
    }

    private String handleSendText(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText != null) {
            ICertificateParser certificateParser = new CertificateParser();
            return certificateParser.parse(sharedText);
        }
        return null;
    }

    public static byte[] readFileContents(Uri fileUri, Context context) {
        InputStream is = null;
        try {
            is = context.getContentResolver().openInputStream(fileUri);
            return getBytes(is);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if(is!=null) {
                try {
                    is.close();
                } catch(Exception e1) {
                    e1.printStackTrace();
                    return null;

                }
            }
        }
    }

    private static byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }

}
