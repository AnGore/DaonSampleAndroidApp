package com.daon.agore.testapp;

/*
* Copyright Daon.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.daon.fido.client.sdk.core.IFidoSdk;
import com.daon.fido.client.sdk.model.UafRequestWithPolicy;
import com.daon.sdk.authenticator.Authenticator;
import com.daon.sdk.device.IXAFingerprintFactor;
import com.google.gson.Gson;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.daon.fido.client.sdk.core.IFidoSdk;
import com.daon.fido.client.sdk.model.Policy;
import com.daon.fido.client.sdk.model.UafRequestWithPolicy;
import com.daon.agore.testapp.exception.*;
import com.daon.sdk.authenticator.Authenticator;
import com.daon.sdk.device.IXAFingerprintFactor;
import com.google.gson.Gson;

/**
 * This contains a number of statics used by multiple activities within the application.
 */
public class CoreApplication {

    public static String USER_IDENTIFIER = "IdentityX_UserId";
    public static String LOGOUT_BROADCAST_ACTION = "com.daon.fido.sdk.sample.logout";
    public static String EXTRA_LOGOUT_SUCCESS = "logoutSuccess";
    public static String EXTRA_LOGOUT_ERROR_CODE = "logoutErrorCode";
    public static String EXTRA_LOGOUT_ERROR_MESSAGE = "logoutErrorMessage";
    public static String EXTRA_LOGOUT_TIMEOUT = "logoutTimeout";
    private static String KEY_LAST_LOGGED_IN_USER_ACCOUNT = "lastLoggedInUserAccount";
    private static long LOGOUT_WAIT = 3 * 60 * 1000;

    private static boolean hasExternalClient;
    private static String sessionId;
    private static String email;
    private static boolean fidoSupported;
    private static String appId;
    private static IFidoSdk fidoSdk;
    private static IRelyingPartyComms relyingPartyComms;
    private static UserLogoutTask userLogoutTask;
    private static Context context;
    private static CountDownTimer logoutCountdown = new CountDownTimer(LOGOUT_WAIT, LOGOUT_WAIT) {

        @Override
        public void onTick(long millisUntilFinished) {
        }

        @Override
        public void onFinish() {
            doLogout(true);
        }
    };

    public static CountDownTimer getLogoutCountdown() {
        return logoutCountdown;
    }

    public static Context getContext() {
        return context;
    }

    public static void setContext(Context context) {
        CoreApplication.context = context;
    }

    public static String getSessionId() {
        return sessionId;
    }

    public static void setSessionId(String theSessionId) {
        sessionId = theSessionId;
    }

    public static String getEmail() {
        return email;
    }

    public static String getLastLoggedInUserEmail() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        return sp.getString(KEY_LAST_LOGGED_IN_USER_ACCOUNT, null);
    }

    public static void setEmail(String theEmail) {
        email = theEmail;
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(KEY_LAST_LOGGED_IN_USER_ACCOUNT, email);
        editor.commit();
    }

    public static boolean isFIDOSupported() {
        return fidoSupported;
    }

    public static void setFIDOSupported(boolean isFIDOSupported) {
        fidoSupported = isFIDOSupported;
    }

    public static void setHasExternalClient(boolean hasExternalClient) {
        CoreApplication.hasExternalClient = hasExternalClient;
    }

    public static boolean hasExternalClient() {
        return hasExternalClient;
    }

    public static String getAppId() {
        return appId;
    }

    public static void setAppId(String uafRequestMessage) {
        Gson gson = new Gson();
        UafRequestWithPolicy[] msg = gson.fromJson(uafRequestMessage, UafRequestWithPolicy[].class);
        msg[0].policy.disallowed = null;
        appId = msg[0].header.appID;
    }

    public static IFidoSdk getFidoSdk() {
        return fidoSdk;
    }

    public static void setFidoSdk(IFidoSdk fidoSdk) {
        CoreApplication.fidoSdk = fidoSdk;
    }

    public static IRelyingPartyComms getRelyingPartyComms() {
        return relyingPartyComms;
    }

    public static void setRelyingPartyComms(IRelyingPartyComms relyingPartyComms) {
        CoreApplication.relyingPartyComms = relyingPartyComms;
    }

    public static void doLogout(boolean timeout) {
        Log.d("SampleRpApp", "doLogout with timeout: " + timeout);
        if(userLogoutTask==null) {
            userLogoutTask = new UserLogoutTask(timeout);
            userLogoutTask.execute();
        }
    }

    public static boolean isFactorSupported(Authenticator.Factor factor) {
        //TODO: Something more clever here but you get the idea!
        if(factor== Authenticator.Factor.EYE) {
            return false;
        }

        if(factor == Authenticator.Factor.FINGERPRINT) {
            if(!IXAFingerprintFactor.isSupported(context, 0))
                return false;
        }
        return true;
    }

    public static class UserLogoutTask extends AsyncTask<Void, Void, ServerOperationResult<Boolean>> {
        private final boolean timeout;

        public UserLogoutTask(boolean timeout) {
            Log.d("SampleRpApp", "init UserLogoutTask with timeout: " + timeout);
            this.timeout = timeout;
        }

        @Override
        protected ServerOperationResult<Boolean> doInBackground(Void... params) {

            ServerOperationResult<Boolean> result;
            try {
                Log.d("SampleRpApp", "Call deleteSession(): " + CoreApplication.getSessionId());
                getRelyingPartyComms().deleteSession(CoreApplication.getSessionId());
                result = new ServerOperationResult<>(true);
            } catch (ServerError e) {
                result = new ServerOperationResult<>(e.getError());
            } catch (CommunicationsException e) {
                result = new ServerOperationResult<>(e.getError());
            }

            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<Boolean> response) {
            Log.d("SampleRpApp", "deleteSession() complete with timeout: " + timeout);
            userLogoutTask = null;

            Intent intent = new Intent(LOGOUT_BROADCAST_ACTION);
            intent.putExtra(EXTRA_LOGOUT_TIMEOUT, timeout);

            if (response.isSuccessful()) {
                Log.d("SampleRpApp", "deleteSession() Success");
                intent.putExtra(EXTRA_LOGOUT_SUCCESS, true);
            } else {
                // Expired session - just logout and ignore the error
                if (response.getError().getCode() == 202) {
                    Log.d("SampleRpApp", "deleteSession() Failed with expired session so success");
                    intent.putExtra(EXTRA_LOGOUT_SUCCESS, true);
                } else {
                    Log.d("SampleRpApp", "deleteSession() Failed. Code: " + response.getError().getCode() +
                            ", Message: " + response.getError().getMessage());
                    intent.putExtra(EXTRA_LOGOUT_SUCCESS, false);
                    intent.putExtra(EXTRA_LOGOUT_ERROR_CODE, response.getError().getCode());
                    intent.putExtra(EXTRA_LOGOUT_ERROR_MESSAGE, response.getError().getMessage());
                }
            }

            Log.d("SampleRpApp", "Broadcast logout intent.");
            LocalBroadcastManager.getInstance(CoreApplication.getContext()).sendBroadcast(intent);
        }

        @Override
        protected void onCancelled() {
            userLogoutTask = null;
        }

    }
}
