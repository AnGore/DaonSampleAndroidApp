package com.daon.agore.testapp;

/*
* Copyright Daon.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.widget.Toast;

import com.daon.fido.client.sdk.uaf.UafMessageUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.DialogPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.daon.fido.client.sdk.uaf.UafMessageUtils;
import com.daon.agore.testapp.ados.*;
//import com.daon.fido.sdk.sample.ados.CertificateParser;
//import com.daon.fido.sdk.sample.ados.ICertificateAccessor;
//import com.daon.fido.sdk.sample.ados.ICertificateParser;
import com.daon.agore.testapp.R;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Displays application settings based on preferences.xml
 */
public class SettingsFragment extends PreferenceFragment {
    private static final int REQ_CODE_CHOOSE_FILE = 123;

    CheckBoxPreference adosRootCertSet;

    /**
     * Displays application settings based on preferences.xml
     * @param savedInstanceState saved instance state
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load the preferences from an XML resource
        addPreferencesFromResource(R.xml.preferences);

        bindPreferenceSummaryToValue(findPreference("pref_server_url"));
        bindPreferenceSummaryToValue(findPreference("pref_server_port"));

        Preference serverUrl = getPreferenceManager().findPreference("pref_server_url");
        if(serverUrl != null) {
            serverUrl.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    EditTextPreference editPref = (EditTextPreference)preference;
                    editPref.getEditText().setSelection( editPref.getText().length() );
                    return true;
                }
            });
        }

        Preference serverPort = getPreferenceManager().findPreference("pref_server_port");
        if(serverPort != null) {
            serverPort.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    EditTextPreference editPref = (EditTextPreference)preference;
                    editPref.getEditText().setSelection( editPref.getText().length() );
                    return true;
                }
            });
        }



        Preference facetid = getPreferenceManager().findPreference("facet_id_preference");
        if (facetid != null) {
            facetid.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {

                @Override
                public boolean onPreferenceClick(Preference preference) {
                    emailFacetID();
                    return true;
                }
            });

            String id = UafMessageUtils.getFacetId(getActivity());
            if (id != null && id.length() > 0)
                facetid.setSummary(id);
        }

        Preference appVersion = getPreferenceManager().findPreference("app_version_preference");
        if(appVersion != null) {
            try {
                PackageInfo packageInfo = getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0);
                if(packageInfo != null) {
                    appVersion.setSummary(packageInfo.versionName);
                }
            }catch (PackageManager.NameNotFoundException e) {

            }
        }

        Preference alwaysAllowNativeAuth = getPreferenceManager().findPreference("pref_native_logon_always");
        alwaysAllowNativeAuth.setEnabled(CoreApplication.hasExternalClient());

        final CheckBoxPreference tabbedRegUI = (CheckBoxPreference)getPreferenceManager().findPreference("pref_tabbed_reg_ui");
        if(tabbedRegUI != null) {
            tabbedRegUI.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {
                    if(tabbedRegUI.isChecked()) {
                        return true;
                    } else {
                        confirmChange(tabbedRegUI, "pref_tabbed_reg_ui");
                        return false;
                    }
                }
            });
        }

        final CheckBoxPreference tabbedAuthUI = (CheckBoxPreference)getPreferenceManager().findPreference("pref_tabbed_auth_ui");
        if(tabbedAuthUI != null) {
            tabbedAuthUI.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {
                    if(tabbedAuthUI.isChecked()) {
                        return true;
                    } else {
                        confirmChange(tabbedAuthUI, "pref_tabbed_auth_ui");
                        return false;
                    }
                }
            });
        }

        adosRootCertSet = (CheckBoxPreference)getPreferenceManager().findPreference("pref_alt_ados_root_cert_provided");
        if(adosRootCertSet != null) {
            adosRootCertSet.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {
                    if(adosRootCertSet.isChecked()) {
                        Toast.makeText(getActivity(), R.string.ados_root_cert_unset, Toast.LENGTH_LONG).show();
                        return true;
                    } else {
                        selectAlternativeAdosRootCert();
                        return false;
                    }
                }
            });
        }

        String alternativeAdosRootCert = getAlternativeAdosRootCertArg();
        if(alternativeAdosRootCert != null) {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
            SharedPreferences.Editor editor = sp.edit();
            editor.putBoolean("pref_alt_ados_root_cert_provided", true);
            editor.commit();
            storeAlternativeAdosRootCert(alternativeAdosRootCert);
        }

        Preference sanPreference = getPreferenceManager().findPreference("pref_ados_dec_san");
        if(sanPreference!=null) {
            sanPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {
                    Toast.makeText(getActivity(), R.string.settings_app_restart_warning, Toast.LENGTH_LONG).show();
                    return true;
                }
            });
        }

        Preference adosEnabledPreference = getPreferenceManager().findPreference("pref_ados_enabled");
        if(adosEnabledPreference!=null) {
            adosEnabledPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {
                    Toast.makeText(getActivity(), R.string.settings_app_restart_warning, Toast.LENGTH_LONG).show();
                    return true;
                }
            });
        }

        Preference screenCaptureEnabledPreference = getPreferenceManager().findPreference("pref_screen_capture");
        if(screenCaptureEnabledPreference!=null) {
            screenCaptureEnabledPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object o) {
                    Toast.makeText(getActivity(), R.string.settings_app_restart_warning, Toast.LENGTH_LONG).show();
                    return true;
                }
            });
        }
    }

    private String getAlternativeAdosRootCertArg() {
        Bundle args = getArguments();
        String base64EncodedCert = null;
        if(args != null) {
            base64EncodedCert = args.getString(SettingsActivity.ARG_ADOS_ROOT_CERT, null);
        }
        return base64EncodedCert;
    }

    private void selectAlternativeAdosRootCert() {
        Intent intent = new Intent()
                .setType("*/*")
                .setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(intent, "Select a file"), REQ_CODE_CHOOSE_FILE);
    }

    private void storeAlternativeAdosRootCert(String base64EncodedCert) {
        ICertificateAccessor certificateAccessor = new CertificateAccessor();
        certificateAccessor.storeCertificate(base64EncodedCert, getActivity());
        if(adosRootCertSet != null) {
            adosRootCertSet.setChecked(true);
        }
        Toast.makeText(getActivity(), R.string.ados_root_cert_set, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQ_CODE_CHOOSE_FILE && resultCode == Activity.RESULT_OK) {
            try {
                byte[] fileContents = SettingsActivity.readFileContents(data.getData(), getActivity());
                ICertificateParser certificateParser = new CertificateParser();
                String base64EncodedCert = certificateParser.parse(fileContents);
                storeAlternativeAdosRootCert(base64EncodedCert);
            } catch(Exception e) {
                Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                return;
            }
        }
    }

    private void confirmChange(final CheckBoxPreference preference, final String key) {
        String message = getString(R.string.confirm_tabbed_ui);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this.getActivity());
        alertDialogBuilder.setMessage(message);

        alertDialogBuilder.setPositiveButton(R.string.dialog_confirm_yes, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                preference.setChecked(true);
                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(getActivity());
                SharedPreferences.Editor editor = sp.edit();
                editor.putBoolean(key, true);
                editor.commit();
            }
        });

        alertDialogBuilder.setNegativeButton(R.string.dialog_confirm_cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void emailFacetID() {
        String id = UafMessageUtils.getFacetId(getActivity());
        if (id != null) {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("message/rfc822");
            sendIntent.putExtra(Intent.EXTRA_SUBJECT, "IdentityX FIDO Facet ID");

            String body = "Facet ID:\n" + id;

            sendIntent.putExtra(Intent.EXTRA_TEXT, body);

            startActivity(Intent.createChooser(sendIntent, "email"));
        }
    }

    /**
     * A preference value change listener that updates the preference's summary
     * to reflect its new value.
     */
    private static Preference.OnPreferenceChangeListener bindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
        @Override
        public boolean onPreferenceChange(Preference preference, Object value) {
            String stringValue = value.toString();

            if (preference instanceof ListPreference) {
                // For list settings, look up the correct display value in
                // the preference's 'entries' list.
                ListPreference listPreference = (ListPreference) preference;
                int index = listPreference.findIndexOfValue(stringValue);

                // Set the summary to reflect the new value.
                preference.setSummary(
                        index >= 0
                                ? listPreference.getEntries()[index]
                                : null);

            } else {
                // For all other settings, set the summary to the value's
                // simple string representation.
                preference.setSummary(stringValue);
            }
            return true;
        }
    };

    /**
     * Binds a preference's summary to its value. More specifically, when the
     * preference's value is changed, its summary (line of text below the
     * preference title) is updated to reflect the value. The summary is also
     * immediately updated upon calling this method. The exact display format is
     * dependent on the type of preference.
     *
     * @see #bindPreferenceSummaryToValueListener
     */
    private static void bindPreferenceSummaryToValue(Preference preference) {

        if (preference == null)
            return;

        // Set the listener to watch for value changes.
        preference.setOnPreferenceChangeListener(bindPreferenceSummaryToValueListener);

        // Trigger the listener immediately with the preference's
        // current value.
        bindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                PreferenceManager
                        .getDefaultSharedPreferences(preference.getContext())
                        .getString(preference.getKey(), ""));
    }
}
