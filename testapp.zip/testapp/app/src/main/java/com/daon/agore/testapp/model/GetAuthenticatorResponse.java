package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class GetAuthenticatorResponse {
    private AuthenticatorInfo authenticatorInfo;

    public AuthenticatorInfo getAuthenticatorInfo() {
        return authenticatorInfo;
    }

    public void setAuthenticatorInfo(AuthenticatorInfo authenticatorInfo) {
        this.authenticatorInfo = authenticatorInfo;
    }


}