package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class CreateAuthenticatorResponse {

    private String fidoRegistrationConfirmation;
    private Long fidoResponseCode;
    private String fidoResponseMsg;

    public CreateAuthenticatorResponse() {
    }

    public String getFidoRegistrationConfirmation() {
        return fidoRegistrationConfirmation;
    }

    public void setFidoRegistrationConfirmation(String fidoRegistrationConfirmation) {
        this.fidoRegistrationConfirmation = fidoRegistrationConfirmation;
    }

    public Long getFidoResponseCode() {
        return fidoResponseCode;
    }

    public void setFidoResponseCode(Long fidoResponseCode) {
        this.fidoResponseCode = fidoResponseCode;
    }

    public String getFidoResponseMsg() {
        return fidoResponseMsg;
    }

    public void setFidoResponseMsg(String fidoResponseMsg) {
        this.fidoResponseMsg = fidoResponseMsg;
    }

}
