package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public enum AuthenticationMethod {

    USERNAME_PASSWORD("Username and password"),
    FIDO_AUTHENTICATION("FIDO Authentication");

    private final String description;

    AuthenticationMethod(String aDescription) {
        this.description = aDescription;
    }

    public String getDescription() {
        return description;
    }

    public String toString() {
        return this.getDescription();
    }

}
