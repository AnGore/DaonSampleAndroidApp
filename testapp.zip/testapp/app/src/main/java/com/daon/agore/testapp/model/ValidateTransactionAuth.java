package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class ValidateTransactionAuth {

    private String fidoAuthenticationResponse;
    private String authenticationRequestId;

    public String getFidoAuthenticationResponse() {
        return fidoAuthenticationResponse;
    }
    public void setFidoAuthenticationResponse(String fidoAuthenticationResponse) {
        this.fidoAuthenticationResponse = fidoAuthenticationResponse;
    }
    public String getAuthenticationRequestId() {
        return authenticationRequestId;
    }
    public void setAuthenticationRequestId(String authenticationRequestId) {
        this.authenticationRequestId = authenticationRequestId;
    }
}
