package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class DeleteAccountResponse {

    private AuthenticatorInfo[] fidoDeregistrationRequests;

    public DeleteAccountResponse() {
    }

    public AuthenticatorInfo[] getFidoDeregistrationRequests() {
        return fidoDeregistrationRequests;
    }

    public void setFidoDeregistrationRequests(AuthenticatorInfo[] fidoDeregistrationRequests) {
        this.fidoDeregistrationRequests = fidoDeregistrationRequests;
    }

}