package com.daon.agore.testapp;

/**
 * Created by agore on 10/23/17.
 */

import com.daon.agore.testapp.model.CreateAccount;
import com.daon.agore.testapp.model.CreateAccountResponse;
import com.daon.agore.testapp.model.CreateSession;
import com.daon.agore.testapp.model.CreateSessionResponse;
import com.daon.agore.testapp.model.CreateAuthRequestResponse;
import com.daon.agore.testapp.model.DeleteAccountResponse;
import com.daon.agore.testapp.model.CreateTransactionAuthRequest;
import com.daon.agore.testapp.model.ValidateTransactionAuth;
import com.daon.agore.testapp.model.ValidateTransactionAuthResponse;
import com.daon.agore.testapp.model.CreateRegRequestResponse;
import com.daon.agore.testapp.model.CreateAuthenticator;
import com.daon.agore.testapp.model.CreateAuthenticatorResponse;
import com.daon.agore.testapp.model.ListAuthenticatorsResponse;
import com.daon.agore.testapp.model.GetAuthenticatorResponse;
import com.daon.agore.testapp.model.GetPolicyResponse;

/***
 * This interface is used by the app to communicate with the server
 */

public interface IRelyingPartyComms {


    CreateAccountResponse  createAccount(CreateAccount createAccount);

    CreateSessionResponse createSession(CreateSession createSession);

    CreateAuthRequestResponse createAuthRequest();

    CreateAuthRequestResponse createAuthRequestPush(String id);


   void deleteSession(String sessionId);

    /***
     6. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * Delete the account and deregister all active FIDO authenticators
     *
     * @param sessionId - the session associated with the account to be deleted
     * @return DeleteAccountResponse
     */
    DeleteAccountResponse deleteAccount(String sessionId);

    /***
     7. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * This creates a FIDO confirmation transaction - like the authentication request
     * but with content to be displayed to the user in the form of text or a graphic
     *
     * @param createTransactionAuthRequest - the details of the transaction
     * @return CreateAuthRequestResponse
     */
    CreateAuthRequestResponse createTransactionAuthRequest(CreateTransactionAuthRequest createTransactionAuthRequest);

    /***
     8. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * The process of validating the transaction authenticated by the user to ensure it is valid
     *
     * @param validateTransactionAuth - the details of the transaction to be validated
     * @return ValidateTransactionAuthResponse
     */
    ValidateTransactionAuthResponse validateTransactionAuthRequest(ValidateTransactionAuth validateTransactionAuth);

    /***
     9. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * Create a FIDO registration request, allowing a user to assocaited a FIDO authenticator with
     * the account.
     *
     * @return CreateRegRequestResponse
     */
    CreateRegRequestResponse createRegRequest();

    /***
     10. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * After the user has confirmed the creation of a new FIDO authenticator in response to the
     * registration request, this operation processes the response form the FIDO authenticator
     *
     * @param createAuthenticator - the details of the authenticator to create
     * @return CreateAuthenticatorResponse
     */
    CreateAuthenticatorResponse createAuthenticator(CreateAuthenticator createAuthenticator);

    /***
     11. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * Returns a list of FIDO authenticators associated with this account.
     *
     * The account is determined from the session.
     *
     * @return ListAuthenticatorsResponse
     */
    ListAuthenticatorsResponse listAuthenticators();

    /***
     12. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * Returns more details about the specified authenticator.
     *
     * @param authenticatorId - the ID of the authenticator to retrieve
     * @return GetAuthenticatorResponse
     */
    GetAuthenticatorResponse getAuthenticator(String authenticatorId);

    /**
     13. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * Returns the specified server policy.
     *
     * @param policyType "reg" to get the registration policy, or "auth" to get the authentication policy.
     * @return GetPolicyResponse
     */
    GetPolicyResponse getPolicy(String policyType);

    /***
     14. PROTECTED OPERATION - the server will only process this if a valid session is in place
     *
     * Deletes the specified authenticator returning the FIDO deregistration request allowing the
     * FIDO authenticator to be disconnected from the relying party application.
     *
     * @param authenticatorId - the ID of the authenticator to delete
     * @return String
     */
    String deleteAuthenticator(String authenticatorId);
}
