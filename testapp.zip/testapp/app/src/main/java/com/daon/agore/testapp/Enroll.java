package com.daon.agore.testapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import com.daon.agore.testapp.barcode.BarcodeCaptureActivity;
import com.daon.agore.testapp.model.CreateAuthRequestResponse;
import com.daon.fido.client.sdk.core.IUafAuthenticationExCallback;
import com.daon.fido.client.sdk.core.IUafCancellableClientOperation;
import com.daon.fido.client.sdk.ui.AuthenticatorChooser;
import com.daon.fido.client.sdk.ui.UserAccountChooser;
import com.google.android.gms.vision.barcode.Barcode;

public class Enroll extends AppCompatActivity  {

    public static final int REQUEST_SCAN                        = 1;

    private static final String ACTION_SPONSOR                  = "sponsor";
    private static final String CODE                            = "sc";
    public static final String SPONSORSHIP_CODE                 = "SponsorshipCode";

    Button register_btn, scan_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enroll);

        scan_btn = (Button) findViewById(R.id.scancode);
        //scan_btn.setOnClickListener(scanCode);
    }

    public void scanCode(View v){
        Log.e ("Enrollment","Inside scanCode function");
        Intent intent = new Intent(Enroll.this, BarcodeCaptureActivity.class);
        intent.putExtra(BarcodeCaptureActivity.AUTO_FOCUS, true);
        intent.putExtra(BarcodeCaptureActivity.USE_FLASH, false);
        startActivityForResult(intent, REQUEST_SCAN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SCAN) {
            if (resultCode == RESULT_OK) {
                if(data != null) {
                    Barcode barcode = data.getParcelableExtra(BarcodeCaptureActivity.BARCODE_OBJECT);
                    String scanRes = barcode.displayValue;
                    Log.e ("Enroll Activity", "Found sponsorship code - "+getSponsorshipCode(scanRes));
                    enrollUser(getSponsorshipCode(scanRes));

                }
            }
        }
    }

    private void enrollUser(String code) {

        try {
            Intent newIntent = new Intent( this, CreateAccountActivity.class);
            if(code != null)
                newIntent.putExtra(SPONSORSHIP_CODE, code);
            startActivity(newIntent);
        } catch (Throwable ex) {
            Log.e ("Enroll", "Inside enrollUser() function. ERROR - "+ex.getMessage());
            return;
        }
    }
    private String getSponsorshipCode(String url) {
        if(url == null || url.isEmpty())
            return null;

        int index = url.indexOf("://");
        if(index >= 0)
            url = url.substring(index+3);
        String[] as = split(url, "?");
        if(as != null && as.length > 1) {
            String action = as[0];
            if(action.equals(ACTION_SPONSOR)) {
                String query = as[1];
                String[] params = split(query, "&");
                if(params != null && params.length > 0) {
                    int len = params.length;
                    for(int i=0; i<len; i++) {
                        String[] kv = split(params[i], "=");
                        if(kv != null && kv.length > 0) {
                            String key = kv[0].toLowerCase();
                            String val = kv[1];
                            if(key.equals(CODE))
                                return val;
                        }
                    }
                }
            }
        }
        return null;
    }

    private String[] split(String str,  String delimiter) {
        String[] array;
        int occurrences = 0;
        int indexOfInnerString = 0;
        int indexOfDelimiter = 0;
        int counter = 0;

        // Check for null input strings.
        if (str == null)
            return null;

        // Check for null or empty delimiter strings.
        if (delimiter.length() <= 0 || delimiter == null)
            return null;


        // If str begins with delimiter then remove it in order
        // to comply with the desired format.

        if (str.startsWith(delimiter)) {
            str = str.substring(delimiter.length());
        }

        // If str does not end with the delimiter then add it
        // to the string in order to comply with the desired format.
        if (!str.endsWith(delimiter)) {
            str += delimiter;
        }

        // Count occurrences of the delimiter in the string.
        // Occurrences should be the same amount of inner strings.
        while((indexOfDelimiter = str.indexOf(delimiter, indexOfInnerString)) != -1) {
            occurrences += 1;
            indexOfInnerString = indexOfDelimiter +
                    delimiter.length();
        }

        // Declare the array with the correct size.
        array = new String[occurrences];

        // Reset the indices.
        indexOfInnerString = 0;
        indexOfDelimiter = 0;

        // Walk across the string again and this time add the
        // strings to the array.
        while((indexOfDelimiter = str.indexOf(delimiter, indexOfInnerString)) != -1) {
            // Add string to array.
            array[counter] = str.substring(indexOfInnerString,indexOfDelimiter);

            // Increment the index to the next character after
            // the next delimiter.
            indexOfInnerString = indexOfDelimiter +
                    delimiter.length();

            // Inc the counter.
            counter += 1;
        }

        return array;
    }
}
