package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class CreateAuthenticator {

    private String fidoReqistrationResponse;
    private String registrationChallengeId;

    public CreateAuthenticator() {
    }

    public String getFidoReqistrationResponse() {
        return fidoReqistrationResponse;
    }

    public void setFidoReqistrationResponse(String fidoReqistrationResponse) {
        this.fidoReqistrationResponse = fidoReqistrationResponse;
    }

    public String getRegistrationChallengeId() {
        return registrationChallengeId;
    }

    public void setRegistrationChallengeId(String registrationChallengeId) {
        this.registrationChallengeId = registrationChallengeId;
    }
}