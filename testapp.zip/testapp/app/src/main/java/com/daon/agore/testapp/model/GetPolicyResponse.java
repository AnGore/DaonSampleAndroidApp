package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class GetPolicyResponse {
    private PolicyInfo policyInfo;

    public PolicyInfo getPolicyInfo() {
        return policyInfo;
    }

    public void setPolicyInfo(PolicyInfo policyInfo) {
        this.policyInfo = policyInfo;
    }
}
