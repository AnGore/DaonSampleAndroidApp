package com.daon.agore.testapp;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.daon.agore.testapp.exception.CommunicationsException;
import com.daon.agore.testapp.exception.ServerError;
import com.daon.agore.testapp.model.CreateAccount;
import com.daon.agore.testapp.model.CreateAccountResponse;
import com.daon.agore.testapp.model.CreateAuthenticator;
import com.daon.agore.testapp.model.CreateAuthenticatorResponse;
import com.daon.fido.client.sdk.core.Error;
import com.daon.fido.client.sdk.core.IChooseAuthenticatorCallback;
import com.daon.fido.client.sdk.core.IFidoSdk;
import com.daon.fido.client.sdk.core.IServerDataAuthenticateCallback;
import com.daon.fido.client.sdk.core.IUafCancellableClientOperation;
import com.daon.fido.client.sdk.core.IUafRegistrationExCallback;
import com.daon.fido.client.sdk.model.Authenticator;
import com.daon.fido.client.sdk.ui.AuthenticatorChooser;
import com.daon.fido.client.sdk.ui.PagedUIAuthenticators;
import com.google.gson.Gson;

import java.util.Locale;

import static com.daon.agore.testapp.BaseActivity.getRelyingPartyComms;

public class CreateAccountActivity extends BaseActivity implements IUafRegistrationExCallback {

    private EditText    et_fname;
    private EditText    et_lname;
    private EditText    et_email;
    private EditText    et_pass;
    private EditText    et_passConfirm;
    private CheckBox    cb_withFido;
    private Button      create_btn;

    private View        mProgressView;
    private View        mSignupFormView;
    private String      sponsorShipCode;
    private boolean     mRegistrationInProgress;

    private UserSignupTask                  enrollmentTask = null;
    private CreateAuthenticatorTask         mCreateAuthenticatorTask = null;
    private CreateAccount                   mCreateAccount = null;
    private CreateAccountResponse           mCreateAccountResponse = null;
    private boolean                         mServerError;
    private AuthenticatorChooser            mAuthChooser;
    private IUafCancellableClientOperation  mRegistrationOperation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("CreateAccount","onCreate()");

        mAuthChooser = new AuthenticatorChooser(this, 10);
        mRegistrationOperation = null;

        setContentView(R.layout.activity_create_account);

        // Set up the signup form.
        et_fname        = (EditText) findViewById(R.id.first_name);
        et_lname        = (EditText) findViewById(R.id.last_name);
        et_email        = (EditText) findViewById(R.id.email);
        et_pass         = (EditText) findViewById(R.id.password);
        et_passConfirm  = (EditText) findViewById(R.id.confirm_password);
        cb_withFido     = (CheckBox) findViewById(R.id.register_with_fido_check_box);

        Bundle extras = getIntent().getExtras();
        if(extras != null)
            sponsorShipCode = extras.getString(Enroll.SPONSORSHIP_CODE, null);

        create_btn = (Button)findViewById(R.id.enroll_button);

        create_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createAccount();
            }
        });

    }

    public void createAccount() {
        final String EA = "Inside createAccount()";
        // Reset errors.
        et_fname.setError(null);
        et_lname.setError(null);
        et_email.setError(null);
        et_pass.setError(null);
        et_passConfirm.setError(null);

        // Store values at the time of the login attempt.
        String firstName        = et_fname.getText().toString();
        String lastName         = et_lname.getText().toString();
        String email            = et_email.getText().toString();
        String password         = et_pass.getText().toString();
        String confirmPassword  = et_passConfirm.getText().toString();

        boolean cancel = false;
        View focusView = null;

        Log.e (EA,"Entered createAccount() function");

        // Check for a first name, if the user entered one.
        if (TextUtils.isEmpty(firstName)) {
            et_fname.setError("Enter First name");
            focusView = et_fname;
            cancel = true;
        } else if (TextUtils.isEmpty(lastName)) {
            et_lname.setError("Enter Last name");
            focusView = et_lname;
            cancel = true;
        }else if (TextUtils.isEmpty(password)) {
            et_pass.setError("Enter Password");
            focusView = et_pass;
            cancel = true;
        }else if (TextUtils.isEmpty(confirmPassword)) {
            et_passConfirm.setError("Enter password");
            focusView = et_passConfirm;
            cancel = true;
        } else if (!password.equals(confirmPassword)) {
            // Check for a valid confirm password, if the user entered one.
            et_passConfirm.setError("Password Mismatch!!!");
            focusView = et_passConfirm;
            cancel = true;
        }else if (TextUtils.isEmpty(email)) {
            et_email.setError("Enter a valid email");
            focusView = et_email;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            Log.e (EA,"First Name is "+firstName);
            Log.e (EA,"Last Name is "+lastName);
            Log.e (EA,"Emai is "+email);
            Log.e (EA,"Password is "+password);
            Log.e (EA,"Register with FIDO? "+cb_withFido.isChecked());

            enrollmentTask = new UserSignupTask(firstName, lastName, email, password, cb_withFido.isChecked());
            mRegistrationInProgress = true;
            Log.e (EA, "Ready to do tasks in background...running execute");
            enrollmentTask.execute((Void) null);
        }
    }

    @Override
    public void chooseAuthenticator(Authenticator[][] authenticatorSets, IChooseAuthenticatorCallback authenticatorChosen) {
        Log.e("CreateAccount Activity","Entered chooseAuthenticator()");
        mAuthChooser.chooseAuthenticator(authenticatorSets, authenticatorChosen);
        Log.e("CreateAccount Activity","Exiting chooseAuthenticator()");

    }

    @Override
    public void onPagedUIAuthenticatorsReady(PagedUIAuthenticators pagedUIAuthenticators) {

    }

    @Override
    public void onUafRegistrationComplete(String regResponse) {
        Log.e ("CreateAccount Activity", "OnUafRegistrationComplete -"+regResponse);
        mCreateAuthenticatorTask = new CreateAuthenticatorTask(mCreateAccountResponse.getRegistrationRequestId(),regResponse);
        mCreateAuthenticatorTask.execute((Void) null);
        return;
    }

    @Override
    public void onUafRegistrationFailed(Error error) {
        Log.e ("CreateAccount Activity", "UafRegistration FAILED -"+error.getMessage());
        return;
    }

    @Override
    public void onServerData(String s, IServerDataAuthenticateCallback iServerDataAuthenticateCallback) {

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e ("CAA", "Request Code -"+requestCode+" resultCode - "+requestCode);

        mAuthChooser.processActivityResult(requestCode, resultCode, data);

        Log.e("CAA", "AAAAAAAAAAAA");
        processRegisterWithTabsActivityResult(requestCode, resultCode, data);
    }

    protected void processRegisterWithTabsActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 11) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    /*
                    String error = data.getStringExtra(RegisterTabActivity.EXTRA_ERROR);

                    String regResponse = data.getStringExtra(RegisterTabActivity.EXTRA_REG_RESPONSE);
                    if(error != null) {
                        onUafRegistrationFailed(new Gson().fromJson(error, Error.class));
                    } else {
                        onUafRegistrationComplete(regResponse);
                    }
                    */
                    Log.e ("CreateAccount Activity", "Inside processRegisterWithTabsActivityResult(), RESULT_OK");
                    break;
                case Activity.RESULT_CANCELED:
                    onUafRegistrationFailed(Error.USER_CANCELLED);
                    break;
            }
        }
    }

    /**
     * Represents an asynchronous task used to create a FIDO authenticator after a successful registration by a UAF client.
     */
    public class CreateAuthenticatorTask extends AsyncTask<Void, Void, ServerOperationResult<CreateAuthenticatorResponse>> {
        private final CreateAuthenticator createAuthenticator;

        CreateAuthenticatorTask(String registrationChallengeId, String fidoRegistrationResponse) {
            Log.e ("CAA","Entering CreateAuthenticatorTask Constructor()");
            createAuthenticator = new CreateAuthenticator();
            createAuthenticator.setRegistrationChallengeId(registrationChallengeId);
            createAuthenticator.setFidoReqistrationResponse(fidoRegistrationResponse);
            Log.e ("CAA","Exiting CreateAuthenticatorTask Constructor()");

        }

        @Override
        protected ServerOperationResult<CreateAuthenticatorResponse> doInBackground(Void... params) {
            ServerOperationResult<CreateAuthenticatorResponse> result;
            Log.e ("CAA","Entering CreateAuthenticatorTask doInBackground()");
            try {
                CreateAuthenticatorResponse response = getRelyingPartyComms().createAuthenticator(this.getCreateAuthenticator());
                result = new ServerOperationResult<>(response);
            } catch (ServerError e) {
                Log.e ("CAA", "Server Error : "+e.getError());
                result = new ServerOperationResult<>(e.getError());
            } catch (CommunicationsException e) {
                Log.e ("CAA","Comm Error : "+e.getError());
                result = new ServerOperationResult<>(e.getError());
            }

            Log.e ("CAA","Exiting CreateAuthenticatorTask doInBackground()");
            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<CreateAuthenticatorResponse> result) {
            mCreateAuthenticatorTask = null;
            mRegistrationOperation = null;

            Log.e ("CAA","Entered CreateAuthenticatorTask onPostExecute()");
            // SERVER RESPONDED OK
            // Server responded OK but this doesn't necessarily mean that an authenticator was created successfully.
            // The response contains a code which indicates success or failure. This response code is sent on to the UAF
            // client so that it might delete the credential it generated on server failure. The response code
            // is also checked by the RP app. If the return code indicates that no error was returned by the server then
            // the log-in success screen is displayed.
            if (result.isSuccessful()) {
                CoreApplication.getFidoSdk().notifyUafResult(result.getResponse().getFidoRegistrationConfirmation(),
                        result.getResponse().getFidoResponseCode().shortValue());
                mRegistrationInProgress = false;

                Log.e ("CAA", "Response code -"+result.getResponse().getFidoResponseCode().intValue());
                Log.e ("CAA", "Reesponse Message -"+result.getResponse().getFidoResponseMsg());
                // UAF REGISTRATION SUCCESS
                if(result.getResponse().getFidoResponseCode().intValue() == 1200) {
                    Log.e ("CreateAccount Activity","UafRegistration SUCCESS");
                    //showProgress(false);
                    //showLoggedIn();
                } else {
                    // UAF REGISTRATION FAILURE
                    //endProgressWithError(result.getResponse().getFidoResponseMsg());
                    Log.e ("CreateAccount Activity","UafRegistration FAILED");

                }
            } else {
                // SERVER ERROR
                // Now we need to send the registration response and server error back to the UAF client.
                CoreApplication.getFidoSdk().notifyUafResult(this.getCreateAuthenticator().getFidoReqistrationResponse(),
                        (short)1500);
                mRegistrationInProgress = false;

                //endProgressWithError(result.getError().getMessage());
            }
        }

        @Override
        protected void onCancelled() {
            mCreateAuthenticatorTask = null;
            //showProgress(false);
        }

        protected CreateAuthenticator getCreateAuthenticator() {
            return createAuthenticator;
        }
    }

    /**
     * Represents an asynchronous task used to create a user account.
     */
    public class UserSignupTask extends AsyncTask<Void, Void, ServerOperationResult<CreateAccountResponse>> {
        private final String UST = "Inside UserSignupTask";
        private final CreateAccount newAccount;

        UserSignupTask(String firstName, String lastName, String email, String password, boolean registrationRequested) {

            newAccount = new CreateAccount();
            newAccount.setFirstName(firstName);
            newAccount.setLastName(lastName);
            newAccount.setEmail(email);
            newAccount.setPassword(password);

            if (registrationRequested)
                Log.e(UST, "FIDO reg requested");
            else
                Log.e(UST, "FIDO reg not requested");

            newAccount.setRegistrationRequested(registrationRequested);

            if (sponsorShipCode != null) {
                Log.e(UST, "Sponsorship Code is " + sponsorShipCode);
                newAccount.setSponsorshipCode(sponsorShipCode);
            }

            newAccount.setLangugae(Locale.getDefault().toString());
        }


        /**
         *  ServerOperationResult() -> Sends registration details to the server
         *  and gets a FIDO Registration Request back.
         *
         */
        @Override
        protected ServerOperationResult<CreateAccountResponse> doInBackground(Void... params) {
            final String SOR = "ServerOperationResult";
            Log.e(SOR, SOR);

            ServerOperationResult<CreateAccountResponse> result;

            try {
                Log.e(SOR, "Communicating with the Server now in order to create account");
                CreateAccountResponse response = getRelyingPartyComms().createAccount(this.getCreateAccount());
                result = new ServerOperationResult<>(response);
            } catch (ServerError e) {
                Log.e(SOR, "Server Error" + e.getError());
                result = new ServerOperationResult<>(e.getError());
            } catch (CommunicationsException e) {
                Log.e(SOR, "Communication error " + e.getMessage());
                result = new ServerOperationResult<>(e.getError());
            }

            return result;
        }

        /**
         *  onPostExecute() -> Sends the registration request to SDK
         */
        @Override
        protected void onPostExecute(final ServerOperationResult<CreateAccountResponse> result) {
            enrollmentTask = null;
            mServerError = false;

            Log.e ("CreateAccountActivity", "onPostExecute()");

            if (result.isSuccessful()) {
                Log.e("CreateAccountActivity", "onPostExecute()-> Sending reg request to SDK");
                //CoreApplication.getFidoSdk().notifyUafResult(result.getResponse().getFidoRegistrationConfirmation(), result.getResponse().getFidoResponseCode().shortValue());

                CoreApplication.setEmail(newAccount.getEmail());
                CoreApplication.setSessionId(result.getResponse().getSessionId());

                if (newAccount.isRegistrationRequested()) {
                    Log.e("CreateAccountActivity", "FIDO registration Requested");

                    // If we do require a FIDO registration, now is the time to call the UAF client to perform the registration.
                    // First store the details as they are required by later stages of processing.
                    mCreateAccount = getCreateAccount();
                    mCreateAccountResponse = result.getResponse();

                    CoreApplication.setAppId(mCreateAccountResponse.getFidoRegistrationRequest());


                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    if (sharedPref.getBoolean("pref_tabbed_reg_ui", false)) {
                        Log.e("CreateAccount Activity", "pref_tab_reg_ui is false");
                    } else {
                        getFidoUaf().setAuthenticatorChoiceUI(IFidoSdk.AuthenticatorChoiceUI.Standard);
                        //CoreApplication.getFidoSdk().setAuthenticatorChoiceUI(IFidoSdk.AuthenticatorChoiceUI.Standard);
                        Log.e("CreateAccount Activity", "Calling register now...");
                        Log.e("CreateAccount Activity","Reg req->"+mCreateAccountResponse.getFidoRegistrationRequest());
                        mRegistrationOperation = (IUafCancellableClientOperation) getFidoUaf().register(mCreateAccountResponse.getFidoRegistrationRequest(), CreateAccountActivity.this);
                    }


                } else {
                    // If we don't require FIDO, we're done at this point
                    //showProgress(false);
                    Toast.makeText(CreateAccountActivity.this, "Account created successfully", Toast.LENGTH_LONG).show();
                }

            } else {
                mRegistrationInProgress = false;
                //endProgressWithError(result.getError().getMessage());
            }

        }

        @Override
        protected void onCancelled() {
            enrollmentTask = null;
            //showProgress(false);
        }

        protected CreateAccount getCreateAccount() {
            return newAccount;
        }
    }


    }
