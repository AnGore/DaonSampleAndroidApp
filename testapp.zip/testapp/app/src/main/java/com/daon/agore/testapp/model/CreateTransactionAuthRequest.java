package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class CreateTransactionAuthRequest {

    private String transactionContentType;
    private String transactionContent;
    private boolean stepUpAuth;

    public boolean isStepUpAuth() {
        return stepUpAuth;
    }
    public void setStepUpAuth(boolean stepUpAuth) {
        this.stepUpAuth = stepUpAuth;
    }
    public String getTransactionContentType() {
        return transactionContentType;
    }
    public void setTransactionContentType(String transactionContentType) {
        this.transactionContentType = transactionContentType;
    }
    public String getTransactionContent() {
        return transactionContent;
    }
    public void setTransactionContent(String transactionContent) {
        this.transactionContent = transactionContent;
    }
}