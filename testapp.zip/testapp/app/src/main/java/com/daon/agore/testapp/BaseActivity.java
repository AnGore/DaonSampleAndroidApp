package com.daon.agore.testapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.daon.fido.client.sdk.core.FidoSdkFactory;
import com.daon.fido.client.sdk.core.IFidoSdk;

import java.util.HashSet;
import java.util.Set;

public abstract class BaseActivity extends Activity {
    // The set of authenticators on the device
    private static Set<String> availableAuthenticatorAaids = new HashSet<>();

    // A link to the interface through which communications to the relying party
    // is routed
    private static IRelyingPartyComms relyingPartyComms;

    private static boolean isUafInitialised = false;

    /**
     * Initialise global interfaces which are made available to all activities which derive from this class
     * @param savedInstanceState the saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(relyingPartyComms==null) {
            relyingPartyComms = new ServerCommunication(this);
            CoreApplication.setRelyingPartyComms(relyingPartyComms);
            CoreApplication.setContext(getBaseContext());
        }
        if(CoreApplication.getFidoSdk()==null) {
            CoreApplication.setFidoSdk(FidoSdkFactory.getFidoSdk(this));
        }
    }

    /**
     * Enable settings menu
     * @param menu The options menu in which you place your items
     * @return true for menu to be displayed, otherwise false
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * React to user selecting Settings
     * @param item The menu item that was selected.
     * @return Return false to allow normal menu processing to proceed, true to consume it here.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_settings:
                openSettings();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /**
     * Display settings menu activity.
     */
    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    protected void displayError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    protected boolean hasFIDOClient() {
        return (availableAuthenticatorAaids.size() > 0);
    }

    protected static boolean hasAuthenticator(String aaid) {
        return availableAuthenticatorAaids.contains(aaid);
    }

    public Set<String> getAvailableAuthenticatorAaidsAsSet() {
        return availableAuthenticatorAaids;
    }

    public String[] getAvailableAuthenticatorAaids() {
        return availableAuthenticatorAaids.toArray(new String[availableAuthenticatorAaids.size()]);
    }

    protected static IRelyingPartyComms getRelyingPartyComms() {
        return relyingPartyComms;
    }

    protected static IFidoSdk getFidoUaf() {
        return CoreApplication.getFidoSdk();
    }

    public static boolean isUafInitialised() {
        return isUafInitialised;
    }

    public static void setIsUafInitialised(boolean isUafInitialised) {
        BaseActivity.isUafInitialised = isUafInitialised;
    }
}
