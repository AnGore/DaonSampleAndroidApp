package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class CreateAuthRequestResponse {

    private String fidoAuthenticationRequest;
    private String authenticationRequestId;

    public CreateAuthRequestResponse() {
    }

    public String getFidoAuthenticationRequest() {
        return fidoAuthenticationRequest;
    }

    public void setFidoAuthenticationRequest(String fidoAuthenticationRequest) {
        this.fidoAuthenticationRequest = fidoAuthenticationRequest;
    }

    public String getAuthenticationRequestId() {
        return authenticationRequestId;
    }

    public void setAuthenticationRequestId(String authenticationRequestId) {
        this.authenticationRequestId = authenticationRequestId;
    }

}
