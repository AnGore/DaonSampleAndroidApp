package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class ListAuthenticatorsResponse {
    private AuthenticatorInfo[] authenticatorInfoList;

    public AuthenticatorInfo[] getAuthenticatorInfoList() {
        return authenticatorInfoList;
    }

    public void setAuthenticatorInfoList(AuthenticatorInfo[] authenticatorInfoList) {
        this.authenticatorInfoList = authenticatorInfoList;
    }
}
