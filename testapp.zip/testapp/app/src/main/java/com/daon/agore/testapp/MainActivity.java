package com.daon.agore.testapp;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.util.Log;
import android.content.Intent;
import android.widget.Button;
import android.widget.Toast;

import com.daon.agore.testapp.exception.CommunicationsException;
import com.daon.agore.testapp.exception.ServerError;
import com.daon.agore.testapp.model.CreateAuthRequestResponse;
import com.daon.agore.testapp.model.CreateSession;
import com.daon.agore.testapp.model.CreateSessionResponse;
import com.daon.fido.client.sdk.core.*;
import com.daon.fido.client.sdk.core.Error;
import com.daon.fido.client.sdk.model.AccountInfo;
import com.daon.fido.client.sdk.model.Authenticator;
import com.daon.fido.client.sdk.model.DiscoveryData;
import com.daon.fido.client.sdk.model.Transaction;
import com.daon.fido.client.sdk.ui.AuthenticatorChooser;
import com.daon.fido.client.sdk.ui.PagedUIAuthenticators;
import com.daon.fido.client.sdk.ui.UserAccountChooser;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends BaseActivity implements IUafAuthenticationExCallback{
    private static final String     TAG                         = "MainActivity";
    private static final int    REQ_CODE_CHOOSE_AUTHENTICATOR   = 10;
    private static final int    REQ_CODE_CHOOSE_ACCOUNT         = 11;

    private InitAuthTask                    fidoAuthTask        = null;
    private CreateAuthRequestResponse       fidoAuthResponse    = null;

    private UserLoginWithFIDOTask           fidoLoginTask       = null;

    private IUafCancellableClientOperation  authOp              = null;
    private AuthenticatorChooser            authenticatorChooser= null;
    private UserAccountChooser              accountChooser      = null;

    Button  list_auth_btn, enroll_btn, verify_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.e (TAG, "Entered MainActivity->onCreate()");
        super.onCreate(savedInstanceState);

        //1. Create the instance of fidoSdk interface in CoreApplication.
        CoreApplication.setFidoSdk(FidoSdkFactory.getFidoSdk(this));


        //2. Set up extra parameters
        Bundle para = new Bundle();
        para.putString("com.daon.sdk.log","true");
        para.putString("com.daon.sdk.ados.enabled","true");
        para.putString("com.daon.sdk.ignoreNativeClients", "false"); //Ignore native clients

        //3. Initialise the fidoSdk
        CoreApplication.getFidoSdk().initialise(para, new IUafInitialiseCallback() {
            @Override
            public void onUafInitialiseComplete() {
                Log.e ("fidoSdk.initialise()", "Initialise complete");
                setIsUafInitialised(true);
            }

            @Override
            public void onUafInitialiseFailed(int code, String msg) {
                Log.e ("fidoSdk.initialise()", "Initialise Failed!!! Code:"+code+" Message:"+msg);
                if (code != Error.SDK_INITIALISING.getCode()){
                    Toast.makeText(MainActivity.this, "ERROR Initialising SDK"+code, Toast.LENGTH_LONG).show();
                }
                setIsUafInitialised(false);
            }
        });

        authenticatorChooser = new AuthenticatorChooser(this,REQ_CODE_CHOOSE_AUTHENTICATOR);
        accountChooser = new UserAccountChooser(this,REQ_CODE_CHOOSE_ACCOUNT);

        setContentView(R.layout.activity_main);

        //4. Set up the 'ListAuthenticator' listener for button
        list_auth_btn = (Button) findViewById(R.id.list_authenticators);
        list_auth_btn.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {
                                                    //4.1 Take user to ListAuthenticator Activity
                                                    Intent intent = new Intent(MainActivity.this,ListAuthenticators.class);
                                                    startActivity(intent);
                                                }
                                            }
        );

        //5. Set up the 'EnrollUser' listener for button
        enroll_btn = (Button) findViewById(R.id.enroll_user);
        enroll_btn.setOnClickListener(new View.OnClickListener() {
                               @Override
                               public void onClick(View view) {
                                   //5.1 Take user to ListAuthenticator Activity
                                   Intent intent = new Intent(MainActivity.this,CreateAccountActivity.class);
                                   startActivity(intent);
                               }
                           }
        );

        //6. Set up the "verifyUser listener for button
        verify_btn = (Button)findViewById(R.id.verify_user);
        verify_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("VerifyUserListener", "VerifyUser clicked");

                //1. Create Auth Request Task and run it in background.
                fidoAuthTask = new InitAuthTask();
                fidoAuthTask.execute((Void) null);
                Log.e("VerifyUserListener","Executed the verify button listener");
            }
        });

        Log.e (TAG, "Exiting onCreate()");

    }

    @Override
    public void onUafAuthenticationComplete(String authenticationResponse) {
        Log.e(TAG, "Inside onUafAuthenticationComplete()");
        Log.e(TAG, "response :"+authenticationResponse.toString());
        fidoLoginTask = new UserLoginWithFIDOTask(fidoAuthResponse.getAuthenticationRequestId(), authenticationResponse);
        fidoLoginTask.execute((Void) null);
        fidoAuthTask = null;
        Log.e(TAG,"Exiting onUafAuthenticationComplete");
    }

    @Override
    public void onUafAuthenticationFailed(Error error) {
        Log.e(TAG,"Inside onUafAuthenticationFailed()");
        showLoginError(error.getMessage());
        Log.e(TAG,"Exiting onUafAuthenticationFailed()");
    }

    @Override
    public void chooseAccount(AccountInfo[] accountInfos, IChooseAccountCallback accountChosen) {
        Log.e(TAG,"Inside chooseAccount() function");
        accountChooser.chooseAccount(accountInfos, accountChosen);
        Log.e(TAG,"Exiting chooseAccount()");
    }

    @Override
    public void chooseAuthenticator(Authenticator[][] authenticators, IChooseAuthenticatorCallback authChosen) {
        Log.e(TAG, "Inside chooseAuthenticator() function");
        Log.e(TAG, "Authenticators :"+authenticators.toString());
        authenticatorChooser.chooseAuthenticator(authenticators, authChosen );
        Log.e(TAG,"Exiting chooseAuthenticator()");
    }

    @Override
    public void onPagedUIAuthenticatorsReady(PagedUIAuthenticators pagedUIAuthenticators) {

    }
    @Override
    public void displayTransaction(Transaction transaction, IDisplayTransactionCallback iDisplayTransactionCallback) {

    }
    @Override
    public void onServerData(String s, IServerDataAuthenticateCallback iServerDataAuthenticateCallback) {

    }

    protected void showLoggedIn(CreateSessionResponse response) {
        Log.e(TAG,"Entering showLoggedIn()");
        try {
            CoreApplication.setSessionId(response.getSessionId());
            CoreApplication.setEmail(response.getEmail());
            Log.e ("MainActivity", "Logged in successfully");
            Log.e ("MainActivity", "First Name :"+response.getFirstName());
            Log.e ("MainActivity", "Last  Name :"+response.getLastName());

        } catch (Throwable e) {
            displayError(e.getMessage());
        }
        Log.e(TAG,"Exiting showLoggedIn()");
    }

    protected void showLoginError(String msg){
        Log.e ("MainActivity", "Login Error");
        Log.e ("MainActivity", "Error message :"+msg);
    }

    @Override
    public void onChooseBackupAuthenticator(BackupAuthenticatorInfo backupAuthenticatorInfo) {

    }

    public class InitAuthTask extends AsyncTask<Void, Void, ServerOperationResult<CreateAuthRequestResponse>>{
        protected static final String TAG="CreateAuthRequestTask";

        InitAuthTask(){}

        @Override
        protected ServerOperationResult<CreateAuthRequestResponse> doInBackground(Void... params) {
            ServerOperationResult<CreateAuthRequestResponse> result;
            Log.e (TAG, "doInBackground() function");

            Log.e(TAG,"Calling createAuthRequest() function now");
            CreateAuthRequestResponse response = getRelyingPartyComms().createAuthRequest();
            Log.e (TAG, "Got response back from server :"+response.toString());
            result = new ServerOperationResult<>(response);

            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<CreateAuthRequestResponse> result){
            fidoAuthTask = null;
            Log.e (TAG,"Inside onPostExecute() function");
            if (result.isSuccessful()){
                fidoAuthResponse = result.getResponse();

                /*
                Log.e (TAG, "Setting AppId to "+fidoAuthResponse.getFidoAuthenticationRequest());
                CoreApplication.setAppId(fidoAuthResponse.getFidoAuthenticationRequest());

                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                //IFidoSdk.AuthenticatorFilter filter = IFidoSdk.AuthenticatorFilter.Unregistered;
                IFidoSdk.AuthenticatorFilter filter = IFidoSdk.AuthenticatorFilter.None;

                if (sharedPref.getBoolean(SettingsActivity.PREF_NATIVE_LOGON_ALWAYS, false)){
                    Log.e(TAG, "I came in here");
                    filter = IFidoSdk.AuthenticatorFilter.UnregisteredEmbedded;
                }
                Log.e(TAG,"calling setAuthenticatorChoiceUI()");
                getFidoUaf().setAuthenticatorChoiceUI(IFidoSdk.AuthenticatorChoiceUI.Standard);
*/

                Log.e(TAG,"calling authenticate() on sdk");

                authOp = (IUafCancellableClientOperation)CoreApplication.getFidoSdk().authenticate(result.getResponse().getFidoAuthenticationRequest(), MainActivity.this);
                //authOp = (IUafCancellableClientOperation)CoreApplication.getFidoSdk().authenticate(result.getResponse().getFidoAuthenticationRequest(),filter, MainActivity.this);
                Log.e(TAG,"Done with authenticate()");
            }else{

            }
        }
    }

    public class UserLoginWithFIDOTask extends AsyncTask<Void, Void, ServerOperationResult<CreateSessionResponse>> {
        private final CreateSession loginSession;

        UserLoginWithFIDOTask(String authReqId, String fidoAuthResponse){
            loginSession = new CreateSession();
            loginSession.setAuthenticationRequestId(authReqId);
            loginSession.setFidoAuthenticationResponse(fidoAuthResponse);
        }

        @Override
        protected ServerOperationResult<CreateSessionResponse> doInBackground(Void... params){
            ServerOperationResult <CreateSessionResponse>   result;
            try{
                CreateSessionResponse response = getRelyingPartyComms().createSession(this.getCreateSession());
                result = new ServerOperationResult<>(response);
            } catch (ServerError e){
                result = new ServerOperationResult<>(e.getError());
            } catch (CommunicationsException e){
                result = new ServerOperationResult<>(e.getError());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<CreateSessionResponse> result){
            fidoLoginTask = null;
            authOp = null;

            if (result.isSuccessful()){
                getFidoUaf().notifyUafResult(result.getResponse().getFidoAuthenticationResponse(), result.getResponse().getFidoResponseCode().shortValue());

                if(result.getResponse().getFidoResponseCode().intValue() == 1200){
                    showLoggedIn(result.getResponse());
                }else{
                    showLoginError(result.getResponse().getFidoResponseMsg());
                }
            }else {
                getFidoUaf().notifyUafResult(this.getCreateSession().getFidoAuthenticationResponse(),(short) 1500);
                showLoginError(result.getError().getMessage());
            }
        }

        public CreateSession getCreateSession() {
            return loginSession;
        }
    }
}
