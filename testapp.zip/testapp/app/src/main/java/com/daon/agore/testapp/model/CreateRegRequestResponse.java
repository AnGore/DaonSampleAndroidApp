package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class CreateRegRequestResponse {
        private String fidoRegistrationRequest;
        private String registrationRequestId;

        public CreateRegRequestResponse() {
        }

        public String getFidoRegistrationRequest() {
            return fidoRegistrationRequest;
        }

        public void setFidoRegistrationRequest(String fidoRegistrationRequest) {
            this.fidoRegistrationRequest = fidoRegistrationRequest;
        }

        public String getRegistrationRequestId() {
            return registrationRequestId;
        }

        public void setRegistrationRequestId(String registrationRequestId) {
            this.registrationRequestId = registrationRequestId;
        }

}
