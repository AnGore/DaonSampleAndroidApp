package com.daon.agore.testapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.daon.fido.client.sdk.core.IUafDiscoverCallback;
import com.daon.fido.client.sdk.model.Authenticator;
import com.daon.fido.client.sdk.model.DiscoveryData;

import java.util.ArrayList;
import java.util.Arrays;

public class ListAuthenticators extends BaseActivity {

    ListView lv;
    Button  btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_authenticators);

        FindAuthenticators auths = new FindAuthenticators();
        auths.execute();

        lv = (ListView) findViewById(R.id.authenticatorsList);
        btn = (Button) findViewById(R.id.back_button);

        btn.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View view) {
                                                 //5. Take user to ListAuthenticator Activity
                                                 Intent intent = new Intent(ListAuthenticators.this,MainActivity.class);
                                                 startActivity(intent);
                                             }
                                         }
        );
    }


    protected void showList(){
        Log.e("Inside showList()","Entered");
        Log.e("ListVal :",getAvailableAuthenticatorAaidsAsSet().toString());

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,getAvailableAuthenticatorAaidsAsSet().toArray());
        lv.setAdapter(arrayAdapter);

    }

    protected void retrieveAvailableAuthenticatorAaids() {
        Log.e("ListActivity","Entering retrieveAvailableAuthentocatorAaids()");

        //1. Call discover method
        CoreApplication.getFidoSdk().discover(new IUafDiscoverCallback() {

            @Override
            public void onUafDiscoverComplete(DiscoveryData result) {
                //2. Get the authenticatros from the returned resultset.
                Authenticator[] auth = result.getAvailableAuthenticators();

                for(Authenticator authenticator : auth) {
                    Log.e ("AAID = ",authenticator.getAaid());
                    Log.e ("Description : ", authenticator.getDescription());

                    if(!authenticator.getAaid().startsWith("D409")) {
                        //CoreApplication.setHasExternalClient(true);
                    }

                    //Update the list of authenticators in BaseActivity
                    getAvailableAuthenticatorAaidsAsSet().add(authenticator.getAaid());
                }
                showList();
            }

            @Override
            public void onUafDiscoverFailed(int code, String message) {
                //displayError("Failed to retrieve authenticators. Code: " + code + ". Reason: " + message);
                Log.e("ERROR", message);
                Log.e ("Code", String.valueOf(code));

            }
        });
    }



    public class FindAuthenticators extends AsyncTask<Void, Void, Void> {

    FindAuthenticators() {
    }

    @Override
    protected Void doInBackground(Void... params) {
        // Wait for UAF to initialise
        retrieveAvailableAuthenticatorAaids();
        return null;
    }

}

}