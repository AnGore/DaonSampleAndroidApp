package com.daon.agore.testapp.model;

/**
 * Created by agore on 10/23/17.
 */

public class CreateAccountResponse {

    private String sessionId;
    private String fidoRegistrationRequest;
    private String registrationRequestId;

    public CreateAccountResponse() {
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }


    public String getFidoRegistrationRequest() {
        return fidoRegistrationRequest;
    }

    public void setFidoRegistrationRequest(String fidoRegistrationRequest) {
        this.fidoRegistrationRequest = fidoRegistrationRequest;
    }

    public String getRegistrationRequestId() {
        return registrationRequestId;
    }

    public void setRegistrationRequestId(String registrationRequestId) {
        this.registrationRequestId = registrationRequestId;
    }
}
