package com.daon.agore.testapp;

import android.app.Activity;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.daon.agore.testapp.exception.CommunicationsException;
import com.daon.agore.testapp.exception.ServerError;
import com.daon.agore.testapp.model.CreateAuthRequestResponse;
import com.daon.agore.testapp.model.CreateSession;
import com.daon.agore.testapp.model.CreateSessionResponse;
import com.daon.fido.client.sdk.core.Error;
import com.daon.fido.client.sdk.core.IChooseAccountCallback;
import com.daon.fido.client.sdk.core.IChooseAuthenticatorCallback;
import com.daon.fido.client.sdk.core.IDisplayTransactionCallback;
import com.daon.fido.client.sdk.core.IServerDataAuthenticateCallback;
import com.daon.fido.client.sdk.core.IUafAuthenticationExCallback;
import com.daon.fido.client.sdk.core.IUafCancellableClientOperation;
import com.daon.fido.client.sdk.model.AccountInfo;
import com.daon.fido.client.sdk.model.Authenticator;
import com.daon.fido.client.sdk.model.Transaction;
import com.daon.fido.client.sdk.ui.AuthenticatorChooser;
import com.daon.fido.client.sdk.ui.PagedUIAuthenticators;
import com.daon.fido.client.sdk.ui.UserAccountChooser;

public class authenticate extends Activity {

}
/*

public class authenticate extends Activity implements IUafAuthenticationExCallback {

    private static final String TAG = "authenticateActivity";
    private static final int    REQ_CODE_CHOOSE_AUTHENTICATOR   = 10;
    private static final int    REQ_CODE_CHOOSE_ACCOUNT         = 11;

    IUafCancellableClientOperation  authOp          = null;
    AuthenticatorChooser            authChooser     = null;
    UserAccountChooser              accountChooser  = null;

    CreateAuthRequestTask           fidoAuthTask    = null;
    CreateAuthRequestResponse       fidoAuthResponse= null;

    UserLoginWithFIDOTask           fidoLoginTask   = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authenticate);

        authChooser = new AuthenticatorChooser(this,REQ_CODE_CHOOSE_AUTHENTICATOR);
        accountChooser = new UserAccountChooser(this,REQ_CODE_CHOOSE_ACCOUNT);

    }

    @Override
    public void chooseAccount(AccountInfo[] accountInfos, IChooseAccountCallback iChooseAccountCallback) {
        Log.e(TAG,"Inside chooseAccount() function");
        accountChooser.chooseAccount(accountInfos, iChooseAccountCallback);
        Log.e(TAG,"Exiting chooseAccount()");
    }

    @Override
    public void chooseAuthenticator(Authenticator[][] authenticators, IChooseAuthenticatorCallback iChooseAuthenticatorCallback) {
        Log.e(TAG, "Inside chooseAuthenticator() function");
        Log.e(TAG, "Authenticators :"+authenticators.toString());
        authChooser.chooseAuthenticator(authenticators, iChooseAuthenticatorCallback );
        Log.e(TAG,"Exiting chooseAuthenticator()");
    }

    @Override
    public void onPagedUIAuthenticatorsReady(PagedUIAuthenticators pagedUIAuthenticators) {

    }

    @Override
    public void displayTransaction(Transaction transaction, IDisplayTransactionCallback iDisplayTransactionCallback) {

    }

    @Override
    public void onUafAuthenticationComplete(String authenticationResponse) {
        Log.e(TAG, "Inside onUafAuthenticationComplete()");
        Log.e(TAG, "response :"+authenticationResponse.toString());
        fidoLoginTask = new UserLoginWithFIDOTask(fidoAuthResponse.getAuthenticationRequestId(), authenticationResponse);
        fidoLoginTask.execute((Void) null);
        fidoAuthTask = null;
        Log.e(TAG,"Exiting onUafAuthenticationComplete");
    }

    @Override
    public void onUafAuthenticationFailed(Error error) {

    }

    @Override
    public void onServerData(String s, IServerDataAuthenticateCallback iServerDataAuthenticateCallback) {

    }

    public class CreateAuthRequestTask extends AsyncTask<Void, Void, ServerOperationResult<CreateAuthRequestResponse>>{
        protected static final String TAG="CreateAuthRequestTask";

        @Override
        protected ServerOperationResult<CreateAuthRequestResponse> doInBackground(Void... params) {
            ServerOperationResult<CreateAuthRequestResponse> result;
            Log.e (TAG, "doInBackground() function");

            Log.e(TAG,"Calling createAuthRequest() function now");
            CreateAuthRequestResponse response = getRelyingPartyComms().createAuthRequest();
            Log.e (TAG, "Got response back from server :"+response.toString());
            result = new ServerOperationResult<>(response);

            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<CreateAuthRequestResponse> result){
            fidoAuthTask = null;
            Log.e (TAG,"Inside onPostExecute() function");
            if (result.isSuccessful()){
                fidoAuthResponse = result.getResponse();
                Log.e(TAG,"calling authenticate() on sdk");

                authOp = (IUafCancellableClientOperation)CoreApplication.getFidoSdk().authenticate(result.getResponse().getFidoAuthenticationRequest(), MainActivity.this);
                //authOp = (IUafCancellableClientOperation)CoreApplication.getFidoSdk().authenticate(result.getResponse().getFidoAuthenticationRequest(),filter, MainActivity.this);
                Log.e(TAG,"Done with authenticate()");
            }else{

            }
        }
    }


    public class UserLoginWithFIDOTask extends AsyncTask<Void, Void, ServerOperationResult<CreateSessionResponse>> {
        private final CreateSession loginSession;

        UserLoginWithFIDOTask(String authReqId, String fidoAuthResponse){
            loginSession = new CreateSession();
            loginSession.setAuthenticationRequestId(authReqId);
            loginSession.setFidoAuthenticationResponse(fidoAuthResponse);
        }

        @Override
        protected ServerOperationResult<CreateSessionResponse> doInBackground(Void... params){
            ServerOperationResult <CreateSessionResponse>   result;
            try{
                CreateSessionResponse response = getRelyingPartyComms().createSession(this.getCreateSession());
                result = new ServerOperationResult<>(response);
            } catch (ServerError e){
                result = new ServerOperationResult<>(e.getError());
            } catch (CommunicationsException e){
                result = new ServerOperationResult<>(e.getError());
            }
            return result;
        }

        @Override
        protected void onPostExecute(final ServerOperationResult<CreateSessionResponse> result){
            fidoLoginTask = null;
            authOp = null;

            if (result.isSuccessful()){
                getFidoUaf().notifyUafResult(result.getResponse().getFidoAuthenticationResponse(), result.getResponse().getFidoResponseCode().shortValue());

                if(result.getResponse().getFidoResponseCode().intValue() == 1200){
                    showLoggedIn(result.getResponse());
                }else{
                    showLoginError(result.getResponse().getFidoResponseMsg());
                }
            }else {
                getFidoUaf().notifyUafResult(this.getCreateSession().getFidoAuthenticationResponse(),(short) 1500);
                showLoginError(result.getError().getMessage());
            }
        }

        public CreateSession getCreateSession() {
            return loginSession;
        }
    }

}
*/